package com.lia.ai
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity:AppCompatActivity(){
 private lateinit var input:EditText; private lateinit var box:LinearLayout; private lateinit var scroll:ScrollView
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);input=findViewById(R.id.input);box=findViewById(R.id.chatContainer);scroll=findViewById(R.id.chatScroll);findViewById<Button>(R.id.send).setOnClickListener{send()};findViewById<Button>(R.id.navChat).setOnClickListener{section("Chat","Parliamo. Scrivi qualcosa a LIA.")};findViewById<Button>(R.id.navAssistant).setOnClickListener{section("Assistente","Qui arriveranno le azioni sul telefono.")};findViewById<Button>(R.id.navRoutines).setOnClickListener{section("Routine","Qui potrai creare routine e automazioni.")};findViewById<Button>(R.id.navSettings).setOnClickListener{section("Impostazioni","Privacy, account, memoria e autorizzazioni.")}}
 private fun send(){val t=input.text.toString().trim();if(t.isEmpty())return;add("Tu\n$t");input.setText("");add("LIA\n${reply(t)}")}
 private fun reply(t:String):String{val s=t.lowercase();if(s.contains("ciao")||s.contains("ehi"))return "Ciao! Sono LIA. 👋";if(s.contains("chi sei"))return "Sono LIA AI, il tuo assistente personale.";if(s.contains("come stai"))return "Tutto pronto. Dimmi cosa vuoi fare.";return "Ho ricevuto: \"$t\". Questa V1 usa un motore locale. Il vero provider AI verrà collegato in seguito."}
 private fun add(t:String){val v=TextView(this);v.text=t;v.setTextColor(resources.getColor(R.color.lia_text));v.textSize=15f;v.setPadding(18,14,18,14);v.setBackgroundResource(R.drawable.bg_card);val p=LinearLayout.LayoutParams(-1,-2);p.bottomMargin=10;box.addView(v,p);scroll.post{scroll.fullScroll(ScrollView.FOCUS_DOWN)}}
 private fun section(t:String,m:String){findViewById<TextView>(R.id.title).text=t;findViewById<TextView>(R.id.subtitle).text=m}
}

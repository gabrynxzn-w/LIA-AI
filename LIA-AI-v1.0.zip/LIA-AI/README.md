# LIA-AI

Prima versione funzionante di LIA AI.

- Chat locale funzionante
- Risposte di base
- Sezioni Chat, Assistente, Routine e Impostazioni
- Nessuna API key nel progetto

Compilare il modulo `app` con Android Studio o un IDE Android compatibile.
